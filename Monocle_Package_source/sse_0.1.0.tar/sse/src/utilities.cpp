#include <Rcpp.h>
#include <RcppEigen.h>

using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::export]]
SEXP calculate_G(const Eigen::MatrixXd& newLambda, const Eigen::MatrixXd& V){ //
  // G <- V %*% (tcrossprod(newLambda, V))
  Eigen::MatrixXd G = V * newLambda * V.transpose();

  return Rcpp::wrap(G);
}
