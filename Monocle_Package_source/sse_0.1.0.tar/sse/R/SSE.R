#' Learning a smooth skeleton in a low-dimensional space from noisy data
#'
#' @param data data matrix where row corresponds to samples and column corresponds to variables.
#' We suggest the users first perform initial dimension reduction (umap, diffusion maps, PCA, etc.)
#' to denoise the data and reveal the dominant structure from the data before apply smooth skeleton
#' embedding (SSE).
#' @param dist_mat A sparse matrix storing a kNN-like graph to denote the local neighboring information.
#' @param embeding_dim number of the embedding dimensions generated from kernel PCA.
#' @param method Two proposed strategies for SSE, L2 (default) or L1. L2 is based on a kNN neighbors
#' where the k is determined by the user. L1 is like l1 graph in our L1Graph method (citation). It
#' won't use any neighborhood information, and will take all other points, as the neighbors. Thus,
#' L2 is faster, L1 is relatively slower.
#' @param para.gamma Gamma parameter is used to make matrix A nonsingular, it is like a round-off
#' parameter. 1e-4 or 1e-5 is good.
#' @param d d corresponds to the embedding dimension. If your data doesn't look like smoothed at lower
#' dimension, it is often much smoothier in high dimension. Thus choosing a higher dimension is
#' suggestive. Note that this situation often happens when your data have outlier groups and the initial
#' dimension mainly corresponds to the separation of those outlier groups.
#' @param knn Number of neighbors when building the kNN graph
#' @param C C is the penalty parameter for loss term.
#' @param maxiter maximum number of iterations.
#' @param beta a parameter to control convergence.
#' @param verbose emit running details
#' @importFrom RSpectra eigs
#' @return a list with Y, K, W, U, V
#' Y is the data points in the embedding space
#' K is the kernel of the data points passed into kPCA for data embedding
#' W is the similarity matrix
#' U is the eigen vectors from the kernel matrix
#' V is the eigen values from the kernel matrix
#' @examples
#' data('iris')
#' SSE_res <- SSE(as.matrix(iris[, 1:4]), verbose = F)
#' plot(SSE_res$Y[, 1],SSE_res$Y[, 2], col = c("red","green3","blue")[unclass(iris$Species)])
#' @export
#'
SSE <- function(data = data,
                dist_mat = NULL,
                embeding_dim = ncol(data),
                method = c('L2', 'L1'),
                para.gamma = 1e-5,
                d = ncol(data),
                knn = 5,
                C = 1e3,
                maxiter = 10,
                beta = 1e2,
                verbose = F) {

  MPE_res <- MPE_fast(data,
                      dist_mat = dist_mat,
                      method = method,
                      para.gamma = para.gamma,
                      d = d,
                      knn = knn,
                      C = C,
                      maxiter = maxiter,
                      beta = beta,
                      verbose = verbose)

  myKPCA_res <- myKPCA(MPE_res$K, embeding_dim)

  return(list(Y = myKPCA_res$Y, K = MPE_res$K, W = MPE_res$W, U = myKPCA_res$U, V = myKPCA_res$V))
}

#' Apply maximum a posteriori (MAP) estimation to embed data points to form a smooth skeleton structure
#'
#' @param X data matrix where row corresponds to samples and column corresponds to variables.
#' We suggest the users first perform initial dimension reduction (umap, diffusion maps, PCA, etc.)
#' to denoise the data and reveal the dominant structure from the data before apply smooth skeleton
#' embedding (SSE).
#' @param dist_mat A sparse matrix storing a kNN-like graph to denote the local neighboring information.
#' @param embeding_dim number of the embedding dimensions generated from kernel PCA.
#' @param method Two proposed strategies for SSE, L2 (default) or L1. L2 is based on a kNN neighbors
#' where the k is determined by the user. L1 is like l1 graph in our L1Graph method (citation). It
#' won't use any neighborhood information, and will take all other points, as the neighbors. Thus,
#' L2 is faster, L1 is relatively slower.
#' @param para.gamma Gamma parameter is used to make matrix A nonsingular, it is like a round-off
#' parameter. 1e-4 or 1e-5 is good.
#' @param d d corresponds to the embedding dimension. If your data doesn't look like smoothed at lower
#' dimension, it is often much smoothier in high dimension. Thus choosing a higher dimension is
#' suggestive. Note that this situation often happens when your data have outlier groups and the initial
#' dimension mainly corresponds to the separation of those outlier groups.
#' @param knn Number of neighbors when building the kNN graph
#' @param C C is the penalty parameter for loss term.
#' @param maxiter maximum number of iterations.
#' @param beta a parameter to control convergence.
#' @param verbose emit running details
#' @importFrom RSpectra eigs
#' @importFrom Matrix sparseMatrix norm colSums t
#' @return a list with K, W
#' K is the kernel of the data points passed into kPCA for data embedding
#' W is the similarity matrix
#' @export
#'
MPE_fast <- function(X, dist_mat = NULL,
                     method = c('L2', 'L1'),
                     para.gamma = 1e-5,
                     d = ncol(X),
                     knn = 50,
                     C = 1e3,
                     maxiter = 10,
                     beta = 1e2,
                     verbose = FALSE) {

  if(!is.null(dist_mat) & !identical(dim(dist_mat), c(nrow(X), nrow(X)))) {
    stop('Please ensure the input kNN like graph (through dist_mat variable) has the same number of cells as that in X variable!')
  }
  dim_vec <- dim(X)
  N <- dim_vec[1]; D <- dim_vec[2]

  # for admm convergence
  ABSTOL <- 1e-4
  RELTOL <- 1e-2
  tau <- 1

  # build mapping function
  if(is.null(dist_mat) == TRUE) {
    normsq <- repmat(matrix(rowSums(X^2), ncol = 1), 1, N)
    dist_mat <- normsq + t(normsq) - 2 * (tcrossprod(X))

    if(method == 'pMVU' | method == 'L2') {
      sidx <- t(apply(dist_mat, 1, function(x) {
        # x[x == 0] <- x[x == 0] + max(x) + 1 # this can be improved (avoid counting the zero points)
        order(x, decreasing = F)  # don't need to do matrix below anymore
      }))
      # sparseMatrix(i = ep, j = ep, p, x, dims, dimname
      knnG <- sparseMatrix(i = repmat(matrix(sidx[, 1], ncol = 1), knn, 1)[, 1], j = reshape(sidx[, 2:(knn+1)], N*knn, 1)[, 1],
                           x = matrix(1, nrow = N*knn, ncol = 1)[, 1], dims = c(N, N))
      knnG_sym <- pmax(knnG, Matrix::t(knnG)) # this pmax may be changed (https://stackoverflow.com/questions/11832170/element-wise-max-operation-on-sparse-matrices-in-r)
    } else if(method == 'L1') {
      if(N <= 500) knnG <- matrix(1, nrow = N, ncol = N) - eye(N, N)
      else {
        knn <- 100
        sidx <- t(apply(dist_mat, 1, function(x) order(x, decreasing = F))) # don't need to do matrix below anymore
        # sparseMatrix(i = ep, j = ep, p, x, dims, dimname
        knnG <- sparseMatrix(i = repmat(matrix(sidx[, 1], ncol = 1), knn, 1)[, 1], j = reshape(sidx[, 2:(knn+1)], N*knn, 1)[, 1],
                             x = matrix(1, nrow = N*knn, ncol = 1)[, 1], dims = c(N, N))
        knnG_sym <- pmax(knnG, Matrix::t(knnG))
      }
    }
  } else {
    knnG <- sparseMatrix(i = dist_mat@i, p = dist_mat@p, dims = dist_mat@Dim, x = 1, index1 = F, dimnames = dist_mat@Dimnames)
    knnG_sym <- pmax(knnG, Matrix::t(knnG)) # this pmax may be changed (https://stackoverflow.com/questions/11832170/element-wise-max-operation-on-sparse-matrices-in-r)
  }

  knnG_sym[upper.tri(knnG_sym)] <- 0
  tmp <- which(as.matrix(knnG_sym) == 1, arr.ind = T)
  rows <- tmp[, 1]; cols <- tmp[, 2]

  ave_dist_mat <- Matrix::rowMeans(dist_mat)

  # precompute quantities
  nvar <- length(rows)
  phi <- matrix(0, nrow = nvar, ncol = 1)
  norm_phi <- matrix(0, nrow = nvar, ncol = 1)
  bis <<- vector("list", N)

  # for(m in 1:nvar) {
  #   i <- rows[m]; j <- cols[m]
  #   phi[m] <- dist_mat[i, j]
  #   norm_phi[m] <- dist_mat[i, j] / ave_dist_mat[i]
  #   bis[[i]] <<- c(bis[[i]], m)
  #   bis[[j]] <<- c(bis[[j]], m)
  # }
  # vectorize the calculation
  phi <- dist_mat[cbind(rows, cols)]
  norm_phi <- dist_mat[cbind(rows, cols)] / ave_dist_mat[rows]
  lapply(1:nvar, function(m) {
    i <- rows[m]; j <- cols[m]
    bis[[i]] <<- c(bis[[i]], m)
    bis[[j]] <<- c(bis[[j]], m)
  });

  # intialize variables
  iter <- 0
  Z <- eye(N, N)
  W <- sparseMatrix(i = {}, j = {}, dims = c(N, N))
  w <- sparseMatrix(i = {}, j = {}, dims = c(nvar, 1))
  gW <- diag(c(Matrix::colSums(W) + para.gamma * matrix(1, nrow = 1, ncol = N))) # - W # could simply remove -W

  # main loop of ADMM
  if(verbose) {
    message('iter	    r norm	   eps pri	    s norm	  eps dual	 objective')
  }

  while(1) {
    if(verbose) {
      message('current iteration is ', iter, ' ......')
    }

    # maintain old value
    oldgW <- gW

    # update G
    teig <- Sys.time()
    Q <- gW + Z / tau

    if(verbose) {
      message('starting eigen decomposition ...')
    }

    tmp <- RSpectra::eigs(Q, nrow(Q), which = "LR")
    V <- tmp$vectors; Lambda <- tmp$values

    if(verbose) {
      message('finish eigen decomposition ...')
    }

    lambda <- Lambda / 2
    newLambda <- diag( c(lambda + sqrt(lambda^2 + matrix(1, nrow = N, ncol = 1) / tau)) )

    if(verbose) {
      message('update G ...')
    }
    # G <- V %*% (tcrossprod(newLambda, V))
    G <- calculate_G(newLambda, V)
    teig <- Sys.time() - teig

    # update W
    if(verbose) {
      message('update W ...')
    }
    t1 <- Sys.time()
    P <- G - Z / tau
    c <- phi / (d * tau) # ensure d is 10

    if(verbose) {
      message('running the loop ...')
    }

    # lapply(1:nvar, function(m, c) {
    #   ii <- rows[m]; jj <- cols[m]
    #   c[m] <<- c[m] + 2 * P[ii, jj] + 2 * para.gamma - P[ii, ii] - P[jj, jj]
    # });
    # vectorize the calculation
    c <- c + 2 * P[cbind(rows, cols)] + 2 * para.gamma - P[cbind(rows, rows)] - P[cbind(cols, cols)]
    t1 <- Sys.time() - t1;

    t2 <- Sys.time()
    if(method == 'pMVU') {

      # lbfgs_res <- lbfgs(obj, grad, w, c = c, tau = tau, l2_reg = l2_reg)
      w <- lbfgs_res$value
    } else if(method == 'L2') {
      l2_reg <- 2 / (C * d)
      # tmp <- loss(w, c, tau, l2_reg)

      if(verbose) {
        message('starting optim function ...')
      }

      # lbfgs_res <- lbfgs(obj, grad, c_fun = c, tau = tau, l2_reg = l2_reg, matrix(as.numeric(w), ncol = 1))
      lbfgs_res <- optim(as.numeric(w), obj_f, gr = grad_f, c_fun = c, tau = tau, l2_reg = l2_reg,
                         method = c("L-BFGS-B"))
      if(verbose) {
        message('finish optim function ...')
      }

      # lbfgs_res <- lbfgs(tmp$obj, tmp$grad, w)
      w <- lbfgs_res$par
    } else if(method == 'L1') {
      reg_param <- beta * 4 / d
      l1_penalty <- reg_param * norm_phi
      tmp <- loss(w, c, tau, 0)
      # use L1 here?
    }
    t2 <- Sys.time() - t2

    if(verbose) {
      message('teig = ', teig, ' t1 = ', t1, ' t2 = ', t2)
    }

    Wl <- sparseMatrix(rows, cols, x = w, dims = c(N, N))
    W <- Wl + Matrix::t(Wl)

    # update Z
    if(verbose) {
      message('update Z ...')
    }
    gW <- diag(c(Matrix::colSums(W) + para.gamma * matrix(1, nrow = 1, ncol = N))) - W
    Z <- Z - tau * (G - gW)

    # update tau using
    if(verbose) {
      message('update tau ...')
    }
    norm_r <- Matrix::norm(G - gW, 'F')
    norm_s <- Matrix::norm(tau * (gW - oldgW), 'F')

    if(norm_r > 10 * norm_s) {
      tau <- 2 * tau
    } else if(norm_s > 10 * norm_r) {
      tau <- tau / 2
    }

    # compute objective value
    if(verbose) {
      message('compute objective value ...')
    }
    R <- chol(G)
    obj <- -2 * sum(log(diag(R))) + (crossprod(w, phi)) / d
    reg_obj <- 0
    if(method == 'L2') {
      reg_obj <- crossprod(w) * 2 / C / d
    } else if(method == 'L1') {
      reg_obj <- Matrix::colSums(abs(W) * norm_phi) * 4 * beta / d
    }
    obj <- obj + reg_obj

    # stopping condition
    if(verbose) {
      message('check stopping condition ...')
    }
    tmp_norm <- c(norm(G, 'F'), Matrix::norm(diag(Matrix::colSums(W)) - W, 'F'), sqrt(para.gamma * N))
    eps_pri <- N * ABSTOL + RELTOL * max(tmp_norm)
    eps_dual <- N * ABSTOL + RELTOL * Matrix::norm(Z, 'F')

    if(verbose) {
      message(iter, ' ', norm_r, ' ', eps_pri, ' ', norm_s, ' ', eps_dual, ' ', obj)
    }

    if(norm_r < eps_pri && norm_s < eps_dual || iter >= maxiter) {
      if(verbose) {
        message(iter, ' ', norm_r, ' ', eps_pri, ' ', norm_s, ' ', eps_dual, ' ', obj)
      }
      break;
    }

    iter <- iter + 1
  }

  if(verbose) {
    message('calculate kernel matrix K ...')
  }
  invG <- V %*% (tcrossprod(diag(1 / diag(newLambda)), V))

  return(list(K = invG, W = W))
}

#' Objective function used for the lbfgs-b optimizer
#'
#' @param w data matrix used for PCA projection
#' @param c_fun number for the top principal components
#' @param tau number for the top principal components
#' @param l2_reg number for the top principal components
#' @export
#'
obj_f <- function(w, c_fun, tau, l2_reg) {
  w <- matrix(w, ncol = 1)
  nvar <- length(w)
  N <- length(bis)

  obj <- 0
  grad <- matrix(0, nrow = nvar, ncol = 1)
  for(i in 1:N) {
    biw <- sum(w[bis[[i]]])
    obj <- obj + biw^2
    grad[bis[[i]]] <- grad[bis[[i]]] + biw
  }

  obj <- tau * (0.5 * obj + norm(w, '2')^2 + t(w) %*% c_fun) + l2_reg * norm(w, '2')^2
  return(obj[1])
}

#' Gradient function used for the lbfgs-b optimizer
#'
#' @param C data matrix used for PCA projection
#' @param L number for the top principal components
#' @import irlba irlba
#' @importFrom stats qnorm
#' @export
#'
grad_f <- function(w, c_fun, tau, l2_reg) {
  w <- matrix(w, ncol = 1)
  nvar <- length(w)
  N <- length(bis)

  obj <- 0
  grad <- matrix(0, nrow = nvar, ncol = 1)
  for(i in 1:N) {
    biw <- sum(w[bis[[i]]])
    obj <- obj + biw^2
    grad[bis[[i]]] <- grad[bis[[i]]] + biw
  }

  grad <- c(tau * (grad + 2 * w + c_fun) + l2_reg * 2 * w)
  return(grad)
}

#' Compute the kPCA projection
#'
#' @param A kernel matrix
#' @param no_dims number of embedding dimension
#' @param verbose emit running details
#' @importFrom RSpectra eigs
#' @export
#'
# perform k-PCA
myKPCA <- function(A, no_dims = 2, verbose = F) {
  N <- nrow(A)
  # centeralize kernel
  column_sum <- colMeans(A)

  J <- (matrix(1, nrow = N, ncol = 1)) %*% column_sum
  K <- A - J - t(J) + sum(column_sum) / ncol(A)

  # eigendecomposition
  # [V,D] = eig(___) returns two optional outputs for any of the previous input syntaxes. D is a diagonal matrix containing the eigenvalues. V is a matrix whose columns are the corresponding right eigenvectors.
  if(verbose) {
    message('performing egendecomposition on the kernel matrix K ...')
  }

  tmp <- RSpectra::eigs(K, no_dims, which = "LR")
  V <- tmp$values
  U <- tmp$vectors

  # eig_res <- eigen(K)
  # V <- eig_res$values
  # U <- eig_res$vectors

  if(verbose) {
    message('finishing performing egendecomposition on the kernel matrix K')
  }

  if(verbose) {
    message('embedding the data points ...')
  }

  Y <- U[, 1:no_dims] %*% diag(sqrt(V[1:no_dims]))

  if(verbose) {
    message('returning results ...')
  }

  return(list(U = U, V = V, Y = Y))
}

#' function to reproduce the behavior of repmat function in matlab to replicate and tile an matrix
#' @param X matrix for tiling and replicate the data
#' @param m a numeric value for tiling a matrix
#' @param n a numeric value for tiling a matrix
#' @return a matrix
repmat <- function (X, m, n) {
  mx = dim(X)[1]
  nx = dim(X)[2]
  matrix(t(matrix(X, mx, nx * n)), mx * m, nx * n, byrow = T)
}

#' function to reproduce the behavior of eye function in matlab
#' @param n number of rows in the returned eye matrix
#' @param m number of columns in the returned eye matrix
#' @return a matrix with diagonal element as 1 while other elements as zero (eye matrix)
#' @export
eye <- function (n, m) {
  mat <- matrix(rep(0, n * m), nrow = n)
  diag(mat) <- 1
  return(mat)
}

#' Reshape matrix or array.
#'
#' @param A data matrix
#' @param ... additional arguments passed to the reshape function
#' @export
#'
reshape <- function(A, ...) {
  if (!is.array(A)) {
    stop(sprintf("argument %s must be matrix or array", sQuote("A")))
  }

  nargs <- length(dots <- list(...))
  dims <- as.integer(if (nargs == 1 && is.size_t(dots[[1]])) {
    dots[[1]]
  } else {
    unlist(dots)
  })

  if (!(length(dims) > 1)) {
    stop("dimensions must be of length greater than 1")
  } else if (!(all(dims > 0))) {
    stop("dimensions must be a positive quantity")
  } else if (prod(dims) != prod(dim(A))) {
    stop("number of elements must not change")
  }

  return(array(as.vector(A), dims))
}
#
# # test the code:
# library(R.matlab)
# R.matlab::writeMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/RData/umap_res_10.mat', X = umap_res)
# matlab_res <- R.matlab::readMat('/Users/xqiu/Dropbox (Personal)/Projects/Monocle3/AAAI2017-code/matlab.mat')
# SSE_res <- SSE(umap_res, verbose = T, maxiter = 10)
# myKPCA_res <- myKPCA(res$K, 10)
#
# load("/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/Jupyter_notebook/Paul_dataset_analysis_final.RData")
# qplot(1:ncol(valid_subset_GSE72857_cds), myKPCA_res$V) + xlim(0, 15) #egenvalue
# #
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 2], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 3], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 4], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 5], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 6], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 7], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 8], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 1], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 3], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 4], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 5], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 6], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 7], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 8], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 2], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 3], myKPCA_res$Y[, 4], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 3], myKPCA_res$Y[, 5], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 3], myKPCA_res$Y[, 6], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 3], myKPCA_res$Y[, 7], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 3], myKPCA_res$Y[, 8], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 3], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 3], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 4], myKPCA_res$Y[, 5], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 4], myKPCA_res$Y[, 6], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 4], myKPCA_res$Y[, 7], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 4], myKPCA_res$Y[, 8], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 4], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 4], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 5], myKPCA_res$Y[, 6], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 5], myKPCA_res$Y[, 7], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 5], myKPCA_res$Y[, 8], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 5], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 5], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 6], myKPCA_res$Y[, 7], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 6], myKPCA_res$Y[, 8], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 6], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 6], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 7], myKPCA_res$Y[, 8], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 7], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 7], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 8], myKPCA_res$Y[, 9], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 8], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)
# qplot(myKPCA_res$Y[, 9], myKPCA_res$Y[, 10], color = pData(valid_subset_GSE72857_cds2)$cell_type2)

# load the matlab results:


# a <- Sys.time()
# res <- MPE_fast(umap_res, verbose = T, maxiter = 10)
# myKPCA_res <- myKPCA(res$K, 10)
# b <- Sys.time()

