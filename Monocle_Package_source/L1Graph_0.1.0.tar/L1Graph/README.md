# L1Graph
An implementation of L1 graph approach to learn trajectory 
